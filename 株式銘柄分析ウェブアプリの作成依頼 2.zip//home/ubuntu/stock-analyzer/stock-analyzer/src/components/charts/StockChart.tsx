import React from 'react';
import { 
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, 
  ResponsiveContainer, AreaChart, Area, BarChart, Bar
} from 'recharts';

interface StockChartProps {
  data: Array<{
    date: string;
    close: number;
    open?: number;
    high?: number;
    low?: number;
    volume?: number;
  }> | null;
  loading: boolean;
  height?: number;
  showVolume?: boolean;
}

const StockChart: React.FC<StockChartProps> = ({ 
  data, 
  loading, 
  height = 400,
  showVolume = true
}) => {
  if (loading) {
    return (
      <div className="bg-white p-6 rounded-lg shadow-md mb-6">
        <div className="animate-pulse">
          <div className="h-4 bg-gray-200 rounded w-1/4 mb-4"></div>
          <div className="h-60 bg-gray-200 rounded w-full"></div>
        </div>
      </div>
    );
  }

  if (!data || data.length === 0) {
    return (
      <div className="bg-white p-6 rounded-lg shadow-md mb-6">
        <p className="text-gray-500">チャートデータが見つかりませんでした。</p>
      </div>
    );
  }

  // 日付フォーマットを調整
  const formatDate = (dateStr) => {
    const date = new Date(dateStr);
    return `${date.getMonth() + 1}/${date.getDate()}`;
  };

  // 価格フォーマットを調整
  const formatPrice = (price) => {
    return `$${price.toFixed(2)}`;
  };

  // ボリュームフォーマットを調整
  const formatVolume = (volume) => {
    if (volume >= 1000000000) {
      return `${(volume / 1000000000).toFixed(1)}B`;
    } else if (volume >= 1000000) {
      return `${(volume / 1000000).toFixed(1)}M`;
    } else if (volume >= 1000) {
      return `${(volume / 1000).toFixed(1)}K`;
    }
    return volume;
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-md mb-6">
      <h3 className="text-lg font-medium text-gray-900 mb-4">株価チャート</h3>
      
      <ResponsiveContainer width="100%" height={height}>
        <LineChart
          data={data}
          margin={{
            top: 5,
            right: 30,
            left: 20,
            bottom: 5,
          }}
        >
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis 
            dataKey="date" 
            tickFormatter={formatDate} 
            minTickGap={30}
          />
          <YAxis 
            domain={['auto', 'auto']} 
            tickFormatter={formatPrice}
          />
          <Tooltip 
            formatter={(value) => [`$${value}`, '終値']}
            labelFormatter={(label) => `日付: ${label}`}
          />
          <Legend />
          <Line 
            type="monotone" 
            dataKey="close" 
            stroke="#8884d8" 
            activeDot={{ r: 8 }} 
            name="終値"
          />
          {data[0].open !== undefined && (
            <Line 
              type="monotone" 
              dataKey="open" 
              stroke="#82ca9d" 
              name="始値"
            />
          )}
          {data[0].high !== undefined && (
            <Line 
              type="monotone" 
              dataKey="high" 
              stroke="#ff7300" 
              name="高値"
            />
          )}
          {data[0].low !== undefined && (
            <Line 
              type="monotone" 
              dataKey="low" 
              stroke="#ff0000" 
              name="安値"
            />
          )}
        </LineChart>
      </ResponsiveContainer>
      
      {showVolume && data[0].volume !== undefined && (
        <div className="mt-6">
          <h3 className="text-lg font-medium text-gray-900 mb-4">出来高</h3>
          <ResponsiveContainer width="100%" height={200}>
            <BarChart
              data={data}
              margin={{
                top: 5,
                right: 30,
                left: 20,
                bottom: 5,
              }}
            >
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis 
                dataKey="date" 
                tickFormatter={formatDate} 
                minTickGap={30}
              />
              <YAxis 
                tickFormatter={formatVolume}
              />
              <Tooltip 
                formatter={(value) => [formatVolume(value), '出来高']}
                labelFormatter={(label) => `日付: ${label}`}
              />
              <Bar dataKey="volume" fill="#8884d8" name="出来高" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      )}
    </div>
  );
};

export default StockChart;
