import React from 'react';

interface MarketSentimentProps {
  symbol: string;
  data: {
    analystRatings?: {
      buy: number;
      hold: number;
      sell: number;
      targetPrice?: number;
      currentPrice?: number;
    };
    sentimentIndicators?: {
      shortTermOutlook?: string;
      intermediateTermOutlook?: string;
      longTermOutlook?: string;
      score?: number;
    };
    recentNews?: Array<{
      title: string;
      date: string;
      summary?: string;
      url?: string;
      sentiment?: 'positive' | 'negative' | 'neutral';
    }>;
  } | null;
  loading: boolean;
}

const MarketSentiment: React.FC<MarketSentimentProps> = ({ symbol, data, loading }) => {
  if (loading) {
    return (
      <div className="bg-white p-6 rounded-lg shadow-md mb-6">
        <h2 className="text-xl font-semibold mb-4">市場センチメント</h2>
        <div className="animate-pulse">
          <div className="h-4 bg-gray-200 rounded w-3/4 mb-4"></div>
          <div className="grid grid-cols-3 gap-4 mb-4">
            <div className="h-20 bg-gray-200 rounded"></div>
            <div className="h-20 bg-gray-200 rounded"></div>
            <div className="h-20 bg-gray-200 rounded"></div>
          </div>
          <div className="h-4 bg-gray-200 rounded w-1/2 mb-2"></div>
          <div className="h-4 bg-gray-200 rounded w-full mb-2"></div>
          <div className="h-4 bg-gray-200 rounded w-full mb-2"></div>
        </div>
      </div>
    );
  }

  if (!data) {
    return (
      <div className="bg-white p-6 rounded-lg shadow-md mb-6">
        <h2 className="text-xl font-semibold mb-4">市場センチメント</h2>
        <p className="text-gray-500">センチメントデータが見つかりませんでした。</p>
      </div>
    );
  }

  // アナリスト評価の合計を計算
  const totalRatings = data.analystRatings 
    ? data.analystRatings.buy + data.analystRatings.hold + data.analystRatings.sell 
    : 0;

  // 目標価格と現在価格の差異を計算
  const priceGap = data.analystRatings?.targetPrice && data.analystRatings?.currentPrice
    ? ((data.analystRatings.targetPrice / data.analystRatings.currentPrice - 1) * 100).toFixed(2)
    : null;

  return (
    <div className="bg-white p-6 rounded-lg shadow-md mb-6">
      <h2 className="text-xl font-semibold mb-4">市場センチメント</h2>
      
      {data.analystRatings && totalRatings > 0 && (
        <div className="mb-6">
          <h3 className="text-lg font-medium text-gray-900 mb-3">アナリストの評価</h3>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-4">
            <div className="bg-gray-50 p-4 rounded-lg">
              <h4 className="text-sm font-medium text-gray-500 mb-1">買い推奨</h4>
              <p className="text-xl font-semibold text-green-600">
                {data.analystRatings.buy} <span className="text-sm text-gray-500">({((data.analystRatings.buy / totalRatings) * 100).toFixed(0)}%)</span>
              </p>
            </div>
            <div className="bg-gray-50 p-4 rounded-lg">
              <h4 className="text-sm font-medium text-gray-500 mb-1">保持推奨</h4>
              <p className="text-xl font-semibold text-yellow-600">
                {data.analystRatings.hold} <span className="text-sm text-gray-500">({((data.analystRatings.hold / totalRatings) * 100).toFixed(0)}%)</span>
              </p>
            </div>
            <div className="bg-gray-50 p-4 rounded-lg">
              <h4 className="text-sm font-medium text-gray-500 mb-1">売り推奨</h4>
              <p className="text-xl font-semibold text-red-600">
                {data.analystRatings.sell} <span className="text-sm text-gray-500">({((data.analystRatings.sell / totalRatings) * 100).toFixed(0)}%)</span>
              </p>
            </div>
            {data.analystRatings.targetPrice && (
              <div className="bg-gray-50 p-4 rounded-lg">
                <h4 className="text-sm font-medium text-gray-500 mb-1">目標株価</h4>
                <p className="text-xl font-semibold text-gray-900">
                  ${data.analystRatings.targetPrice.toFixed(2)}
                  {priceGap && (
                    <span className={`text-sm ml-2 ${parseFloat(priceGap) > 0 ? 'text-green-600' : 'text-red-600'}`}>
                      ({priceGap}%)
                    </span>
                  )}
                </p>
              </div>
            )}
          </div>
        </div>
      )}
      
      {data.sentimentIndicators && (
        <div className="mb-6">
          <h3 className="text-lg font-medium text-gray-900 mb-3">センチメント指標</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {data.sentimentIndicators.shortTermOutlook && (
              <div className="bg-gray-50 p-4 rounded-lg">
                <h4 className="text-sm font-medium text-gray-500 mb-1">短期見通し</h4>
                <p className={`text-lg font-semibold ${
                  data.sentimentIndicators.shortTermOutlook.includes('ポジティブ') ? 'text-green-600' : 
                  data.sentimentIndicators.shortTermOutlook.includes('ネガティブ') ? 'text-red-600' : 'text-yellow-600'
                }`}>
                  {data.sentimentIndicators.shortTermOutlook}
                </p>
              </div>
            )}
            
            {data.sentimentIndicators.intermediateTermOutlook && (
              <div className="bg-gray-50 p-4 rounded-lg">
                <h4 className="text-sm font-medium text-gray-500 mb-1">中期見通し</h4>
                <p className={`text-lg font-semibold ${
                  data.sentimentIndicators.intermediateTermOutlook.includes('ポジティブ') ? 'text-green-600' : 
                  data.sentimentIndicators.intermediateTermOutlook.includes('ネガティブ') ? 'text-red-600' : 'text-yellow-600'
                }`}>
                  {data.sentimentIndicators.intermediateTermOutlook}
                </p>
              </div>
            )}
            
            {data.sentimentIndicators.longTermOutlook && (
              <div className="bg-gray-50 p-4 rounded-lg">
                <h4 className="text-sm font-medium text-gray-500 mb-1">長期見通し</h4>
                <p className={`text-lg font-semibold ${
                  data.sentimentIndicators.longTermOutlook.includes('ポジティブ') ? 'text-green-600' : 
                  data.sentimentIndicators.longTermOutlook.includes('ネガティブ') ? 'text-red-600' : 'text-yellow-600'
                }`}>
                  {data.sentimentIndicators.longTermOutlook}
                </p>
              </div>
            )}
          </div>
        </div>
      )}
      
      {data.recentNews && data.recentNews.length > 0 && (
        <div>
          <h3 className="text-lg font-medium text-gray-900 mb-3">最近のニュース</h3>
          <div className="space-y-4">
            {data.recentNews.map((news, index) => (
              <div key={index} className="border-l-4 border-gray-200 pl-4">
                <h4 className="font-medium text-gray-900">{news.title}</h4>
                <p className="text-sm text-gray-500 mb-1">{news.date}</p>
                {news.summary && <p className="text-gray-700 text-sm">{news.summary}</p>}
                {news.sentiment && (
                  <span className={`inline-block px-2 py-1 text-xs rounded-full mt-2 ${
                    news.sentiment === 'positive' ? 'bg-green-100 text-green-800' : 
                    news.sentiment === 'negative' ? 'bg-red-100 text-red-800' : 'bg-yellow-100 text-yellow-800'
                  }`}>
                    {news.sentiment === 'positive' ? 'ポジティブ' : news.sentiment === 'negative' ? 'ネガティブ' : '中立'}
                  </span>
                )}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default MarketSentiment;
