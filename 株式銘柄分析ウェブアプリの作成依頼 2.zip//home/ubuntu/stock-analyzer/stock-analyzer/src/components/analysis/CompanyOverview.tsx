import React from 'react';

interface CompanyOverviewProps {
  symbol: string;
  data: {
    name?: string;
    description?: string;
    sector?: string;
    industry?: string;
    employees?: number;
    website?: string;
    address?: string;
    exchange?: string;
  } | null;
  loading: boolean;
}

const CompanyOverview: React.FC<CompanyOverviewProps> = ({ symbol, data, loading }) => {
  if (loading) {
    return (
      <div className="bg-white p-6 rounded-lg shadow-md mb-6">
        <h2 className="text-xl font-semibold mb-4">企業概要</h2>
        <div className="animate-pulse">
          <div className="h-4 bg-gray-200 rounded w-3/4 mb-4"></div>
          <div className="h-4 bg-gray-200 rounded w-full mb-2"></div>
          <div className="h-4 bg-gray-200 rounded w-full mb-2"></div>
          <div className="h-4 bg-gray-200 rounded w-5/6 mb-4"></div>
          <div className="grid grid-cols-2 gap-4">
            <div className="h-4 bg-gray-200 rounded"></div>
            <div className="h-4 bg-gray-200 rounded"></div>
            <div className="h-4 bg-gray-200 rounded"></div>
            <div className="h-4 bg-gray-200 rounded"></div>
          </div>
        </div>
      </div>
    );
  }

  if (!data) {
    return (
      <div className="bg-white p-6 rounded-lg shadow-md mb-6">
        <h2 className="text-xl font-semibold mb-4">企業概要</h2>
        <p className="text-gray-500">データが見つかりませんでした。</p>
      </div>
    );
  }

  return (
    <div className="bg-white p-6 rounded-lg shadow-md mb-6">
      <h2 className="text-xl font-semibold mb-4">企業概要</h2>
      <div className="mb-4">
        <h3 className="text-lg font-medium text-gray-900">{data.name || symbol}</h3>
        {data.exchange && <p className="text-sm text-gray-500">{data.exchange}</p>}
      </div>
      
      {data.description && (
        <div className="mb-4">
          <p className="text-gray-700">{data.description}</p>
        </div>
      )}
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {data.sector && (
          <div>
            <span className="text-sm font-medium text-gray-500">セクター:</span>
            <p className="text-gray-900">{data.sector}</p>
          </div>
        )}
        
        {data.industry && (
          <div>
            <span className="text-sm font-medium text-gray-500">業種:</span>
            <p className="text-gray-900">{data.industry}</p>
          </div>
        )}
        
        {data.employees && (
          <div>
            <span className="text-sm font-medium text-gray-500">従業員数:</span>
            <p className="text-gray-900">{data.employees.toLocaleString()}</p>
          </div>
        )}
        
        {data.website && (
          <div>
            <span className="text-sm font-medium text-gray-500">ウェブサイト:</span>
            <p className="text-gray-900">
              <a href={data.website} target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline">
                {data.website}
              </a>
            </p>
          </div>
        )}
        
        {data.address && (
          <div className="md:col-span-2">
            <span className="text-sm font-medium text-gray-500">本社所在地:</span>
            <p className="text-gray-900">{data.address}</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default CompanyOverview;
