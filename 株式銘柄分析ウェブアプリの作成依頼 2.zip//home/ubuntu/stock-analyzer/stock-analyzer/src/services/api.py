from flask import Flask, request, jsonify
import sys
sys.path.append('/opt/.manus/.sandbox-runtime')
from stockDataService import StockDataService

app = Flask(__name__)
stock_service = StockDataService()

@app.route('/api/stock/chart', methods=['GET'])
def get_stock_chart():
    symbol = request.args.get('symbol')
    region = request.args.get('region', 'US')
    interval = request.args.get('interval', '1mo')
    range_param = request.args.get('range', '1y')
    
    if not symbol:
        return jsonify({"error": "Symbol parameter is required"}), 400
    
    data = stock_service.get_stock_chart(symbol, region, interval, range_param)
    return jsonify(data)

@app.route('/api/stock/profile', methods=['GET'])
def get_stock_profile():
    symbol = request.args.get('symbol')
    region = request.args.get('region', 'US')
    
    if not symbol:
        return jsonify({"error": "Symbol parameter is required"}), 400
    
    data = stock_service.get_stock_profile(symbol, region)
    return jsonify(data)

@app.route('/api/stock/insights', methods=['GET'])
def get_stock_insights():
    symbol = request.args.get('symbol')
    
    if not symbol:
        return jsonify({"error": "Symbol parameter is required"}), 400
    
    data = stock_service.get_stock_insights(symbol)
    return jsonify(data)

@app.route('/api/stock/holders', methods=['GET'])
def get_stock_holders():
    symbol = request.args.get('symbol')
    region = request.args.get('region', 'US')
    
    if not symbol:
        return jsonify({"error": "Symbol parameter is required"}), 400
    
    data = stock_service.get_stock_holders(symbol, region)
    return jsonify(data)

@app.route('/api/stock/sec-filing', methods=['GET'])
def get_stock_sec_filing():
    symbol = request.args.get('symbol')
    region = request.args.get('region', 'US')
    
    if not symbol:
        return jsonify({"error": "Symbol parameter is required"}), 400
    
    data = stock_service.get_stock_sec_filing(symbol, region)
    return jsonify(data)

@app.route('/api/stock/analyst-opinions', methods=['GET'])
def get_analyst_opinions():
    symbol = request.args.get('symbol')
    region = request.args.get('region', 'US')
    
    if not symbol:
        return jsonify({"error": "Symbol parameter is required"}), 400
    
    data = stock_service.get_analyst_opinions(symbol, region)
    return jsonify(data)

@app.route('/api/stock/analyze', methods=['GET'])
def analyze_stock():
    """
    総合的な株式分析を行うエンドポイント
    """
    symbol = request.args.get('symbol')
    region = request.args.get('region', 'US')
    
    if not symbol:
        return jsonify({"error": "Symbol parameter is required"}), 400
    
    # 各種データを取得
    profile = stock_service.get_stock_profile(symbol, region)
    chart = stock_service.get_stock_chart(symbol, region)
    insights = stock_service.get_stock_insights(symbol)
    holders = stock_service.get_stock_holders(symbol, region)
    
    # 分析結果をまとめる
    analysis = {
        "symbol": symbol,
        "profile": profile,
        "chart": chart,
        "insights": insights,
        "holders": holders
    }
    
    return jsonify(analysis)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
