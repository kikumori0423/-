import axios from 'axios';

// APIのベースURL
const API_BASE_URL = 'http://localhost:5000/api';

// 株式データを取得するサービス
export const stockService = {
  // 株価チャートデータを取得
  async getStockChart(symbol, region = 'US', interval = '1mo', range = '1y') {
    try {
      const response = await axios.get(`${API_BASE_URL}/stock/chart`, {
        params: { symbol, region, interval, range }
      });
      return response.data;
    } catch (error) {
      console.error('Error fetching stock chart:', error);
      throw error;
    }
  },

  // 企業プロファイル情報を取得
  async getStockProfile(symbol, region = 'US') {
    try {
      const response = await axios.get(`${API_BASE_URL}/stock/profile`, {
        params: { symbol, region }
      });
      return response.data;
    } catch (error) {
      console.error('Error fetching stock profile:', error);
      throw error;
    }
  },

  // 株式の分析情報を取得
  async getStockInsights(symbol) {
    try {
      const response = await axios.get(`${API_BASE_URL}/stock/insights`, {
        params: { symbol }
      });
      return response.data;
    } catch (error) {
      console.error('Error fetching stock insights:', error);
      throw error;
    }
  },

  // 株主情報を取得
  async getStockHolders(symbol, region = 'US') {
    try {
      const response = await axios.get(`${API_BASE_URL}/stock/holders`, {
        params: { symbol, region }
      });
      return response.data;
    } catch (error) {
      console.error('Error fetching stock holders:', error);
      throw error;
    }
  },

  // SEC提出書類情報を取得
  async getStockSecFiling(symbol, region = 'US') {
    try {
      const response = await axios.get(`${API_BASE_URL}/stock/sec-filing`, {
        params: { symbol, region }
      });
      return response.data;
    } catch (error) {
      console.error('Error fetching SEC filings:', error);
      throw error;
    }
  },

  // アナリストの意見を取得
  async getAnalystOpinions(symbol, region = 'US') {
    try {
      const response = await axios.get(`${API_BASE_URL}/stock/analyst-opinions`, {
        params: { symbol, region }
      });
      return response.data;
    } catch (error) {
      console.error('Error fetching analyst opinions:', error);
      throw error;
    }
  },

  // 総合的な株式分析を取得
  async analyzeStock(symbol, region = 'US') {
    try {
      const response = await axios.get(`${API_BASE_URL}/stock/analyze`, {
        params: { symbol, region }
      });
      return response.data;
    } catch (error) {
      console.error('Error analyzing stock:', error);
      throw error;
    }
  }
};

export default stockService;
