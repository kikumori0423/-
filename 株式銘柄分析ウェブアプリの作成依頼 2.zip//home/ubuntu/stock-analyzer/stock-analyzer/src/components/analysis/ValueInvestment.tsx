import React from 'react';

interface ValueInvestmentProps {
  symbol: string;
  data: {
    intrinsicValue?: number;
    currentPrice?: number;
    marginOfSafety?: number;
    growthMetrics?: {
      revenueGrowth?: number;
      earningsGrowth?: number;
      dividendGrowth?: number;
      cashFlowGrowth?: number;
    };
    valuationMetrics?: {
      peRatio?: number;
      forwardPE?: number;
      priceToCashFlow?: number;
      priceToBook?: number;
      dividendYield?: number;
      peg?: number;
    };
    riskFactors?: string[];
  } | null;
  loading: boolean;
}

const ValueInvestment: React.FC<ValueInvestmentProps> = ({ symbol, data, loading }) => {
  if (loading) {
    return (
      <div className="bg-white p-6 rounded-lg shadow-md mb-6">
        <h2 className="text-xl font-semibold mb-4">バリュー投資分析</h2>
        <div className="animate-pulse">
          <div className="h-4 bg-gray-200 rounded w-3/4 mb-4"></div>
          <div className="grid grid-cols-3 gap-4 mb-4">
            <div className="h-20 bg-gray-200 rounded"></div>
            <div className="h-20 bg-gray-200 rounded"></div>
            <div className="h-20 bg-gray-200 rounded"></div>
          </div>
          <div className="h-4 bg-gray-200 rounded w-1/2 mb-2"></div>
          <div className="h-4 bg-gray-200 rounded w-full mb-2"></div>
        </div>
      </div>
    );
  }

  if (!data) {
    return (
      <div className="bg-white p-6 rounded-lg shadow-md mb-6">
        <h2 className="text-xl font-semibold mb-4">バリュー投資分析</h2>
        <p className="text-gray-500">バリュー投資データが見つかりませんでした。</p>
      </div>
    );
  }

  // 本質的価値と現在価格の差異を計算
  const valueGap = data.intrinsicValue && data.currentPrice
    ? ((data.intrinsicValue / data.currentPrice - 1) * 100).toFixed(2)
    : null;

  // 安全マージンの評価
  const getSafetyMarginRating = (margin: number | undefined) => {
    if (margin === undefined) return { text: 'データなし', color: 'text-gray-500' };
    if (margin >= 50) return { text: '非常に高い', color: 'text-green-600' };
    if (margin >= 30) return { text: '高い', color: 'text-green-500' };
    if (margin >= 15) return { text: '適切', color: 'text-yellow-600' };
    if (margin >= 0) return { text: '低い', color: 'text-orange-500' };
    return { text: 'なし（割高）', color: 'text-red-600' };
  };

  const safetyMarginRating = getSafetyMarginRating(data.marginOfSafety);

  return (
    <div className="bg-white p-6 rounded-lg shadow-md mb-6">
      <h2 className="text-xl font-semibold mb-4">バリュー投資分析</h2>
      
      <div className="mb-6">
        <h3 className="text-lg font-medium text-gray-900 mb-3">本質的価値評価</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-gray-50 p-4 rounded-lg">
            <h4 className="text-sm font-medium text-gray-500 mb-1">推定本質的価値</h4>
            <p className="text-xl font-semibold text-gray-900">
              {data.intrinsicValue ? `$${data.intrinsicValue.toFixed(2)}` : 'N/A'}
            </p>
          </div>
          <div className="bg-gray-50 p-4 rounded-lg">
            <h4 className="text-sm font-medium text-gray-500 mb-1">現在価格</h4>
            <p className="text-xl font-semibold text-gray-900">
              {data.currentPrice ? `$${data.currentPrice.toFixed(2)}` : 'N/A'}
            </p>
          </div>
          <div className="bg-gray-50 p-4 rounded-lg">
            <h4 className="text-sm font-medium text-gray-500 mb-1">安全マージン</h4>
            <p className={`text-xl font-semibold ${safetyMarginRating.color}`}>
              {data.marginOfSafety !== undefined ? `${data.marginOfSafety.toFixed(2)}%` : 'N/A'}
            </p>
            <p className="text-xs text-gray-500">{safetyMarginRating.text}</p>
          </div>
        </div>
      </div>
      
      {data.growthMetrics && (
        <div className="mb-6">
          <h3 className="text-lg font-medium text-gray-900 mb-3">成長指標</h3>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            {data.growthMetrics.revenueGrowth !== undefined && (
              <div className="bg-gray-50 p-4 rounded-lg">
                <h4 className="text-sm font-medium text-gray-500 mb-1">売上成長率（年率）</h4>
                <p className={`text-xl font-semibold ${data.growthMetrics.revenueGrowth >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                  {(data.growthMetrics.revenueGrowth * 100).toFixed(2)}%
                </p>
              </div>
            )}
            
            {data.growthMetrics.earningsGrowth !== undefined && (
              <div className="bg-gray-50 p-4 rounded-lg">
                <h4 className="text-sm font-medium text-gray-500 mb-1">利益成長率（年率）</h4>
                <p className={`text-xl font-semibold ${data.growthMetrics.earningsGrowth >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                  {(data.growthMetrics.earningsGrowth * 100).toFixed(2)}%
                </p>
              </div>
            )}
            
            {data.growthMetrics.dividendGrowth !== undefined && (
              <div className="bg-gray-50 p-4 rounded-lg">
                <h4 className="text-sm font-medium text-gray-500 mb-1">配当成長率（年率）</h4>
                <p className={`text-xl font-semibold ${data.growthMetrics.dividendGrowth >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                  {(data.growthMetrics.dividendGrowth * 100).toFixed(2)}%
                </p>
              </div>
            )}
            
            {data.growthMetrics.cashFlowGrowth !== undefined && (
              <div className="bg-gray-50 p-4 rounded-lg">
                <h4 className="text-sm font-medium text-gray-500 mb-1">キャッシュフロー成長率（年率）</h4>
                <p className={`text-xl font-semibold ${data.growthMetrics.cashFlowGrowth >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                  {(data.growthMetrics.cashFlowGrowth * 100).toFixed(2)}%
                </p>
              </div>
            )}
          </div>
        </div>
      )}
      
      {data.valuationMetrics && (
        <div className="mb-6">
          <h3 className="text-lg font-medium text-gray-900 mb-3">バリュエーション指標</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {data.valuationMetrics.peRatio !== undefined && (
              <div className="bg-gray-50 p-4 rounded-lg">
                <h4 className="text-sm font-medium text-gray-500 mb-1">PER（株価収益率）</h4>
                <p className="text-xl font-semibold text-gray-900">{data.valuationMetrics.peRatio.toFixed(2)}</p>
              </div>
            )}
            
            {data.valuationMetrics.forwardPE !== undefined && (
              <div className="bg-gray-50 p-4 rounded-lg">
                <h4 className="text-sm font-medium text-gray-500 mb-1">予想PER</h4>
                <p className="text-xl font-semibold text-gray-900">{data.valuationMetrics.forwardPE.toFixed(2)}</p>
              </div>
            )}
            
            {data.valuationMetrics.priceToCashFlow !== undefined && (
              <div className="bg-gray-50 p-4 rounded-lg">
                <h4 className="text-sm font-medium text-gray-500 mb-1">株価キャッシュフロー倍率</h4>
                <p className="text-xl font-semibold text-gray-900">{data.valuationMetrics.priceToCashFlow.toFixed(2)}</p>
              </div>
            )}
            
            {data.valuationMetrics.priceToBook !== undefined && (
              <div className="bg-gray-50 p-4 rounded-lg">
                <h4 className="text-sm font-medium text-gray-500 mb-1">PBR（株価純資産倍率）</h4>
                <p className="text-xl font-semibold text-gray-900">{data.valuationMetrics.priceToBook.toFixed(2)}</p>
              </div>
            )}
            
            {data.valuationMetrics.dividendYield !== undefined && (
              <div className="bg-gray-50 p-4 rounded-lg">
                <h4 className="text-sm font-medium text-gray-500 mb-1">配当利回り</h4>
                <p className="text-xl font-semibold text-green-600">{(data.valuationMetrics.dividendYield * 100).toFixed(2)}%</p>
              </div>
            )}
            
            {data.valuationMetrics.peg !== undefined && (
              <div className="bg-gray-50 p-4 rounded-lg">
                <h4 className="text-sm font-medium text-gray-500 mb-1">PEG比率</h4>
                <p className={`text-xl font-semibold ${data.valuationMetrics.peg < 1 ? 'text-green-600' : data.valuationMetrics.peg < 2 ? 'text-yellow-600' : 'text-red-600'}`}>
                  {data.valuationMetrics.peg.toFixed(2)}
                </p>
                <p className="text-xs text-gray-500">
                  {data.valuationMetrics.peg < 1 ? '割安' : data.valuationMetrics.peg < 2 ? '適正' : '割高'}
                </p>
              </div>
            )}
          </div>
        </div>
      )}
      
      {data.riskFactors && data.riskFactors.length > 0 && (
        <div>
          <h3 className="text-lg font-medium text-gray-900 mb-3">リスク要因</h3>
          <ul className="list-disc pl-5 space-y-1 text-gray-700">
            {data.riskFactors.map((risk, index) => (
              <li key={index}>{risk}</li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
};

export default ValueInvestment;
