import React, { useState } from 'react';
import MainLayout from './components/layout/MainLayout';
import StockSearch from './components/search/StockSearch';
import CompanyOverview from './components/analysis/CompanyOverview';
import FinancialData from './components/analysis/FinancialData';
import MarketSentiment from './components/analysis/MarketSentiment';
import TechnicalAnalysis from './components/analysis/TechnicalAnalysis';
import CompetitorComparison from './components/analysis/CompetitorComparison';
import ValueInvestment from './components/analysis/ValueInvestment';
import InvestmentThesis from './components/analysis/InvestmentThesis';
import StockChart from './components/charts/StockChart';
import FinancialChart from './components/charts/FinancialChart';
import DataTable from './components/tables/DataTable';
import MetricsRadarChart from './components/charts/MetricsRadarChart';
import { useStockData } from './hooks/useStockData';

function App() {
  const [symbol, setSymbol] = useState('');
  const { 
    chartData, 
    profileData, 
    insightsData, 
    holdersData,
    isLoading 
  } = useStockData(symbol);

  const handleSearch = (newSymbol) => {
    setSymbol(newSymbol);
  };

  // チャートデータの変換
  const stockChartData = chartData.data?.series.map(item => ({
    date: item.date,
    close: item.close,
    open: item.open,
    high: item.high,
    low: item.low,
    volume: item.volume
  }));

  // 財務指標のレーダーチャートデータ
  const financialMetricsData = [
    { subject: '収益成長率', value: 75, fullMark: 100 },
    { subject: '利益率', value: 80, fullMark: 100 },
    { subject: '負債比率', value: 65, fullMark: 100 },
    { subject: 'ROE', value: 85, fullMark: 100 },
    { subject: 'キャッシュフロー', value: 70, fullMark: 100 },
    { subject: '配当利回り', value: 60, fullMark: 100 },
  ];

  // 市場シェアの円グラフデータ
  const marketShareData = {
    pieData: [
      { name: '自社', value: 35, color: '#0088FE' },
      { name: '競合他社1', value: 25, color: '#00C49F' },
      { name: '競合他社2', value: 20, color: '#FFBB28' },
      { name: 'その他', value: 20, color: '#FF8042' },
    ],
    title: '市場シェア分析',
    type: 'pie'
  };

  // 四半期収益の棒グラフデータ
  const quarterlyRevenueData = {
    barData: [
      { name: 'Q1', value: 4000, color: '#0088FE' },
      { name: 'Q2', value: 4500, color: '#00C49F' },
      { name: 'Q3', value: 5100, color: '#FFBB28' },
      { name: 'Q4', value: 6000, color: '#FF8042' },
    ],
    title: '四半期収益 (百万円)',
    type: 'bar',
    yAxisLabel: '収益',
    tooltipLabel: '収益'
  };

  // アナリスト評価のテーブルデータ
  const analystRatingsData = [
    { firm: 'JPモルガン', rating: '買い', targetPrice: 185.00, date: '2025-02-15' },
    { firm: 'ゴールドマン・サックス', rating: '買い', targetPrice: 195.00, date: '2025-02-10' },
    { firm: 'モルガン・スタンレー', rating: '保持', targetPrice: 175.00, date: '2025-02-05' },
    { firm: 'バンク・オブ・アメリカ', rating: '買い', targetPrice: 190.00, date: '2025-01-28' },
    { firm: 'ドイツ銀行', rating: '保持', targetPrice: 170.00, date: '2025-01-20' },
  ];

  return (
    <MainLayout>
      <StockSearch onSearch={handleSearch} />
      
      {symbol && (
        <div className="space-y-6">
          {/* 株価チャートセクション */}
          <div className="bg-white p-6 rounded-lg shadow-md mb-6">
            <h2 className="text-xl font-semibold mb-4">株価チャート分析</h2>
            <StockChart 
              data={stockChartData} 
              loading={chartData.isLoading} 
              height={400}
              showVolume={true}
            />
          </div>
          
          {/* 企業概要セクション */}
          <CompanyOverview 
            symbol={symbol} 
            data={profileData.data} 
            loading={profileData.isLoading} 
          />
          
          {/* 財務データセクション */}
          <div className="bg-white p-6 rounded-lg shadow-md mb-6">
            <h2 className="text-xl font-semibold mb-4">財務データ分析</h2>
            
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
              <FinancialChart data={quarterlyRevenueData} height={300} />
              <MetricsRadarChart 
                data={financialMetricsData} 
                title="財務指標評価" 
                height={300} 
                loading={false}
              />
            </div>
            
            <FinancialData 
              symbol={symbol} 
              data={{
                revenue: chartData.data?.series.map(s => s.close * 1000000),
                revenueGrowth: [0.05, 0.07, 0.04, 0.06],
                netIncome: chartData.data?.series.map(s => s.close * 100000),
                profitMargin: [0.15, 0.16, 0.14, 0.17],
                operatingMargin: [0.22, 0.23, 0.21, 0.24],
                periods: chartData.data?.series.map(s => s.date),
                totalAssets: 1000000000,
                totalLiabilities: 400000000,
                totalEquity: 600000000,
                cashFlow: {
                  operating: 120000000,
                  investing: -50000000,
                  financing: -30000000
                }
              }} 
              loading={chartData.isLoading} 
            />
          </div>
          
          {/* 市場センチメントセクション */}
          <div className="bg-white p-6 rounded-lg shadow-md mb-6">
            <h2 className="text-xl font-semibold mb-4">市場センチメント分析</h2>
            
            <div className="mb-6">
              <h3 className="text-lg font-medium text-gray-900 mb-3">アナリスト評価</h3>
              <DataTable 
                data={analystRatingsData}
                columns={[
                  { key: 'firm', header: '証券会社' },
                  { key: 'rating', header: '評価', 
                    render: (value) => (
                      <span className={
                        value === '買い' ? 'text-green-600 font-medium' : 
                        value === '売り' ? 'text-red-600 font-medium' : 'text-yellow-600 font-medium'
                      }>
                        {value}
                      </span>
                    )
                  },
                  { key: 'targetPrice', header: '目標株価', 
                    render: (value) => `$${value.toFixed(2)}`
                  },
                  { key: 'date', header: '更新日' }
                ]}
                title="アナリスト評価一覧"
              />
            </div>
            
            <MarketSentiment 
              symbol={symbol} 
              data={{
                analystRatings: insightsData.data?.recommendation ? {
                  buy: 10,
                  hold: 5,
                  sell: 2,
                  targetPrice: insightsData.data.recommendation.targetPrice,
                  currentPrice: chartData.data?.series[chartData.data.series.length - 1].close
                } : undefined,
                sentimentIndicators: insightsData.data?.technicalEvents ? {
                  shortTermOutlook: insightsData.data.technicalEvents.shortTermOutlook?.direction === 'up' ? 'ポジティブ' : 'ネガティブ',
                  intermediateTermOutlook: insightsData.data.technicalEvents.intermediateTermOutlook?.direction === 'up' ? 'ポジティブ' : 'ネガティブ',
                  longTermOutlook: insightsData.data.technicalEvents.longTermOutlook?.direction === 'up' ? 'ポジティブ' : 'ネガティブ',
                  score: insightsData.data.technicalEvents.shortTermOutlook?.score
                } : undefined,
                recentNews: insightsData.data?.sigDevs?.map(news => ({
                  title: news.headline,
                  date: news.date,
                  sentiment: Math.random() > 0.5 ? 'positive' : 'negative'
                }))
              }} 
              loading={insightsData.isLoading} 
            />
          </div>
          
          {/* テクニカル分析セクション */}
          <TechnicalAnalysis 
            symbol={symbol} 
            data={{
              priceData: chartData.data ? {
                dates: chartData.data.series.map(s => s.date),
                prices: chartData.data.series.map(s => s.close),
                volumes: chartData.data.series.map(s => s.volume)
              } : undefined,
              indicators: {
                sma50: chartData.data?.series.map(s => s.close * 0.95),
                sma200: chartData.data?.series.map(s => s.close * 0.9),
                rsi: chartData.data?.series.map(() => Math.random() * 100),
                macd: {
                  line: chartData.data?.series.map(() => Math.random() * 10 - 5),
                  signal: chartData.data?.series.map(() => Math.random() * 10 - 5),
                  histogram: chartData.data?.series.map(() => Math.random() * 2 - 1)
                }
              },
              supportResistance: {
                support: [
                  chartData.data?.series[chartData.data.series.length - 1].close * 0.9,
                  chartData.data?.series[chartData.data.series.length - 1].close * 0.85
                ],
                resistance: [
                  chartData.data?.series[chartData.data.series.length - 1].close * 1.1,
                  chartData.data?.series[chartData.data.series.length - 1].close * 1.15
                ]
              }
            }} 
            loading={chartData.isLoading} 
          />
          
          {/* 競合他社比較セクション */}
          <div className="bg-white p-6 rounded-lg shadow-md mb-6">
            <h2 className="text-xl font-semibold mb-4">競合他社比較</h2>
            
            <div className="mb-6">
              <FinancialChart data={marketShareData} height={300} />
            </div>
            
            <CompetitorComparison 
              symbol={symbol} 
              data={{
                competitors: [
                  {
                    symbol: symbol,
                    name: profileData.data?.name || symbol,
                    marketCap: 1000000000000,
                    revenue: 400000000000,
                    netIncome: 100000000000,
                    peRatio: 25.4,
                    priceToSales: 6.2,
                    priceToBook: 15.3,
                    debtToEquity: 0.42,
                    returnOnEquity: 0.35,
                    returnOnAssets: 0.25
                  },
                  {
                    symbol: 'COMP1',
                    name: '競合他社1',
                    marketCap: 800000000000,
                    revenue: 350000000000,
                    netIncome: 80000000000,
                    peRatio: 22.1,
                    priceToSales: 5.8,
                    priceToBook: 12.7,
                    debtToEquity: 0.38,
                    returnOnEquity: 0.32,
                    returnOnAssets: 0.22
                  },
                  {
                    symbol: 'COMP2',
                    name: '競合他社2',
                    marketCap: 600000000000,
                    revenue: 250000000000,
                    netIncome: 60000000000,
                    peRatio: 18.5,
                    priceToSales: 4.9,
                    priceToBook: 10.2,
                    debtToEquity: 0.45,
                    returnOnEquity: 0.28,
                    returnOnAssets: 0.18
                  }
                ],
                marketShare: {
                  company: 0.35,
                  competitors: {
                    '競合他社1': 0.25,
                    '競合他社2': 0.20
                  },
                  others: 0.20
                }
              }} 
              loading={isLoading} 
            />
          </div>
          
          {/* バリュー投資分析セクション */}
          <ValueInvestment 
            symbol={symbol} 
            data={{
              intrinsicValue: chartData.data?.series[chartData.data.series.length - 1].close * 1.2,
              currentPrice: chartData.data?.series[chartData.data.series.length - 1].close,
              marginOfSafety: 20,
              growthMetrics: {
                revenueGrowth: 0.12,
                earningsGrowth: 0.15,
                dividendGrowth: 0.08,
                cashFlowGrowth: 0.10
              },
              valuationMetrics: {
                peRatio: 25.4,
                forwardPE: 22.8,
                priceToCashFlow: 18.6,
                priceToBook: 15.3,
                dividendYield: 0.015,
                peg: 1.2
              },
              riskFactors: [
                '市場競争の激化',
                '規制環境の変化',
                'サプライチェーンの混乱リスク',
                '技術革新への対応遅れ'
              ]
            }} 
            loading={isLoading} 
          />
          
          {/* 投資論セクション */}
          <InvestmentThesis 
            symbol={symbol} 
            data={{
              swot: {
                strengths: [
                  '強力なブランド力と市場シェア',
                  '高い利益率と安定したキャッシュフロー',
                  '革新的な製品開発能力',
                  'グローバルな販売網'
                ],
                weaknesses: [
                  '特定市場への依存度が高い',
                  '製品ラインの多様性不足',
                  '高コスト構造',
                  '一部地域での市場浸透率の低さ'
                ],
                opportunities: [
                  '新興市場での成長機会',
                  'デジタルトランスフォーメーションの加速',
                  '新技術の採用による効率化',
                  '戦略的買収による事業拡大'
                ],
                threats: [
                  '競合他社からの価格圧力',
                  '技術の急速な変化',
                  '規制環境の厳格化',
                  'マクロ経済の不確実性'
                ]
              },
              recommendations: {
                valueInvestor: '長期保有推奨。安定したキャッシュフローと適切な安全マージンを持つ。',
                growthInvestor: '買い推奨。新興市場での成長機会と製品イノベーションが将来の成長を支える。',
                incomeInvestor: '保有推奨。安定した配当と配当成長率が魅力的。',
                momentumTrader: '様子見。短期的なモメンタムは中立的だが、四半期決算後に再評価。',
                shortTermTrader: '短期的な価格変動に注意。技術的指標は混合シグナルを示している。'
              },
              summary: `${profileData.data?.name || symbol}は、強固な市場ポジションと安定した財務基盤を持つ企業である。長期的な成長見通しは良好だが、短期的には市場の不確実性と競争圧力に直面している。バリュエーションは適正範囲内にあり、長期投資家にとっては魅力的な投資先となる可能性がある。ただし、技術変化への対応と新興市場での展開が今後の成長の鍵となるだろう。`
            }} 
            loading={isLoading} 
          />
        </div>
      )}
    </MainLayout>
  );
}

export default App;
