import React from 'react';

interface CompetitorComparisonProps {
  symbol: string;
  data: {
    competitors?: Array<{
      symbol: string;
      name: string;
      marketCap?: number;
      revenue?: number;
      netIncome?: number;
      peRatio?: number;
      priceToSales?: number;
      priceToBook?: number;
      debtToEquity?: number;
      returnOnEquity?: number;
      returnOnAssets?: number;
    }>;
    marketShare?: {
      company: number;
      competitors: Record<string, number>;
      others?: number;
    };
  } | null;
  loading: boolean;
}

const CompetitorComparison: React.FC<CompetitorComparisonProps> = ({ symbol, data, loading }) => {
  if (loading) {
    return (
      <div className="bg-white p-6 rounded-lg shadow-md mb-6">
        <h2 className="text-xl font-semibold mb-4">競合他社比較</h2>
        <div className="animate-pulse">
          <div className="h-4 bg-gray-200 rounded w-3/4 mb-4"></div>
          <div className="h-60 bg-gray-200 rounded w-full mb-4"></div>
          <div className="h-4 bg-gray-200 rounded w-1/2 mb-2"></div>
          <div className="h-4 bg-gray-200 rounded w-full mb-2"></div>
        </div>
      </div>
    );
  }

  if (!data || !data.competitors || data.competitors.length === 0) {
    return (
      <div className="bg-white p-6 rounded-lg shadow-md mb-6">
        <h2 className="text-xl font-semibold mb-4">競合他社比較</h2>
        <p className="text-gray-500">競合他社データが見つかりませんでした。</p>
      </div>
    );
  }

  // 自社のデータを取得
  const companyData = data.competitors.find(comp => comp.symbol === symbol);
  
  // 競合他社のデータ（自社を除く）
  const competitorsData = data.competitors.filter(comp => comp.symbol !== symbol);

  return (
    <div className="bg-white p-6 rounded-lg shadow-md mb-6">
      <h2 className="text-xl font-semibold mb-4">競合他社比較</h2>
      
      <div className="mb-6 overflow-x-auto">
        <h3 className="text-lg font-medium text-gray-900 mb-3">主要財務指標比較</h3>
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">企業</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">時価総額 (10億円)</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">売上高 (10億円)</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">純利益 (10億円)</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">PER</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">PSR</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">PBR</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">D/E比率</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">ROE</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">ROA</th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {/* 自社のデータ行 */}
            {companyData && (
              <tr className="bg-blue-50">
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{companyData.name} ({companyData.symbol})</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{companyData.marketCap ? (companyData.marketCap / 1000000000).toFixed(2) : 'N/A'}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{companyData.revenue ? (companyData.revenue / 1000000000).toFixed(2) : 'N/A'}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{companyData.netIncome ? (companyData.netIncome / 1000000000).toFixed(2) : 'N/A'}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{companyData.peRatio?.toFixed(2) || 'N/A'}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{companyData.priceToSales?.toFixed(2) || 'N/A'}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{companyData.priceToBook?.toFixed(2) || 'N/A'}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{companyData.debtToEquity?.toFixed(2) || 'N/A'}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{companyData.returnOnEquity ? (companyData.returnOnEquity * 100).toFixed(2) + '%' : 'N/A'}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{companyData.returnOnAssets ? (companyData.returnOnAssets * 100).toFixed(2) + '%' : 'N/A'}</td>
              </tr>
            )}
            
            {/* 競合他社のデータ行 */}
            {competitorsData.map((competitor, index) => (
              <tr key={index}>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{competitor.name} ({competitor.symbol})</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{competitor.marketCap ? (competitor.marketCap / 1000000000).toFixed(2) : 'N/A'}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{competitor.revenue ? (competitor.revenue / 1000000000).toFixed(2) : 'N/A'}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{competitor.netIncome ? (competitor.netIncome / 1000000000).toFixed(2) : 'N/A'}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{competitor.peRatio?.toFixed(2) || 'N/A'}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{competitor.priceToSales?.toFixed(2) || 'N/A'}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{competitor.priceToBook?.toFixed(2) || 'N/A'}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{competitor.debtToEquity?.toFixed(2) || 'N/A'}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{competitor.returnOnEquity ? (competitor.returnOnEquity * 100).toFixed(2) + '%' : 'N/A'}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{competitor.returnOnAssets ? (competitor.returnOnAssets * 100).toFixed(2) + '%' : 'N/A'}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      
      {data.marketShare && (
        <div>
          <h3 className="text-lg font-medium text-gray-900 mb-3">市場シェア</h3>
          <div className="bg-gray-50 p-4 rounded-lg">
            <div className="mb-2">
              <span className="text-sm font-medium text-gray-500">自社シェア:</span>
              <span className="ml-2 text-gray-900">{(data.marketShare.company * 100).toFixed(2)}%</span>
            </div>
            
            <div className="mb-2">
              <span className="text-sm font-medium text-gray-500">競合他社シェア:</span>
              <div className="ml-4 mt-1 space-y-1">
                {Object.entries(data.marketShare.competitors).map(([compName, share], index) => (
                  <div key={index}>
                    <span className="text-gray-900">{compName}: {(share * 100).toFixed(2)}%</span>
                  </div>
                ))}
              </div>
            </div>
            
            {data.marketShare.others !== undefined && (
              <div>
                <span className="text-sm font-medium text-gray-500">その他:</span>
                <span className="ml-2 text-gray-900">{(data.marketShare.others * 100).toFixed(2)}%</span>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default CompetitorComparison;
