import React from 'react';

interface TechnicalAnalysisProps {
  symbol: string;
  data: {
    priceData?: {
      dates: string[];
      prices: number[];
      volumes: number[];
    };
    indicators?: {
      sma50?: number[];
      sma200?: number[];
      rsi?: number[];
      macd?: {
        line: number[];
        signal: number[];
        histogram: number[];
      };
    };
    supportResistance?: {
      support: number[];
      resistance: number[];
    };
  } | null;
  loading: boolean;
}

const TechnicalAnalysis: React.FC<TechnicalAnalysisProps> = ({ symbol, data, loading }) => {
  if (loading) {
    return (
      <div className="bg-white p-6 rounded-lg shadow-md mb-6">
        <h2 className="text-xl font-semibold mb-4">テクニカル分析</h2>
        <div className="animate-pulse">
          <div className="h-4 bg-gray-200 rounded w-3/4 mb-4"></div>
          <div className="h-60 bg-gray-200 rounded w-full mb-4"></div>
          <div className="grid grid-cols-2 gap-4">
            <div className="h-4 bg-gray-200 rounded"></div>
            <div className="h-4 bg-gray-200 rounded"></div>
            <div className="h-4 bg-gray-200 rounded"></div>
            <div className="h-4 bg-gray-200 rounded"></div>
          </div>
        </div>
      </div>
    );
  }

  if (!data) {
    return (
      <div className="bg-white p-6 rounded-lg shadow-md mb-6">
        <h2 className="text-xl font-semibold mb-4">テクニカル分析</h2>
        <p className="text-gray-500">テクニカルデータが見つかりませんでした。</p>
      </div>
    );
  }

  // 最新の価格データを取得
  const latestPrice = data.priceData?.prices ? data.priceData.prices[data.priceData.prices.length - 1] : null;
  const previousPrice = data.priceData?.prices ? data.priceData.prices[data.priceData.prices.length - 2] : null;
  const priceChange = latestPrice && previousPrice ? ((latestPrice / previousPrice - 1) * 100).toFixed(2) : null;

  // RSIの最新値
  const latestRSI = data.indicators?.rsi ? data.indicators.rsi[data.indicators.rsi.length - 1] : null;

  // MACDの最新値
  const latestMACD = data.indicators?.macd ? {
    line: data.indicators.macd.line[data.indicators.macd.line.length - 1],
    signal: data.indicators.macd.signal[data.indicators.macd.signal.length - 1],
    histogram: data.indicators.macd.histogram[data.indicators.macd.histogram.length - 1]
  } : null;

  // サポート/レジスタンスレベル
  const supportLevels = data.supportResistance?.support || [];
  const resistanceLevels = data.supportResistance?.resistance || [];

  return (
    <div className="bg-white p-6 rounded-lg shadow-md mb-6">
      <h2 className="text-xl font-semibold mb-4">テクニカル分析</h2>
      
      <div className="mb-6">
        <h3 className="text-lg font-medium text-gray-900 mb-3">価格動向</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-gray-50 p-4 rounded-lg">
            <h4 className="text-sm font-medium text-gray-500 mb-1">最新価格</h4>
            <p className="text-xl font-semibold text-gray-900">
              {latestPrice ? `$${latestPrice.toFixed(2)}` : 'N/A'}
            </p>
          </div>
          <div className="bg-gray-50 p-4 rounded-lg">
            <h4 className="text-sm font-medium text-gray-500 mb-1">価格変動</h4>
            <p className={`text-xl font-semibold ${priceChange && parseFloat(priceChange) >= 0 ? 'text-green-600' : 'text-red-600'}`}>
              {priceChange ? `${priceChange}%` : 'N/A'}
            </p>
          </div>
          <div className="bg-gray-50 p-4 rounded-lg">
            <h4 className="text-sm font-medium text-gray-500 mb-1">出来高（最新）</h4>
            <p className="text-xl font-semibold text-gray-900">
              {data.priceData?.volumes ? (data.priceData.volumes[data.priceData.volumes.length - 1] / 1000000).toFixed(2) + 'M' : 'N/A'}
            </p>
          </div>
        </div>
      </div>
      
      <div className="mb-6">
        <h3 className="text-lg font-medium text-gray-900 mb-3">テクニカル指標</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {data.indicators?.sma50 && (
            <div className="bg-gray-50 p-4 rounded-lg">
              <h4 className="text-sm font-medium text-gray-500 mb-1">SMA 50日</h4>
              <p className="text-xl font-semibold text-gray-900">
                ${data.indicators.sma50[data.indicators.sma50.length - 1].toFixed(2)}
              </p>
              <p className="text-xs text-gray-500">
                {latestPrice && latestPrice > data.indicators.sma50[data.indicators.sma50.length - 1] 
                  ? '価格は50日移動平均線を上回っています（強気）' 
                  : '価格は50日移動平均線を下回っています（弱気）'}
              </p>
            </div>
          )}
          
          {data.indicators?.sma200 && (
            <div className="bg-gray-50 p-4 rounded-lg">
              <h4 className="text-sm font-medium text-gray-500 mb-1">SMA 200日</h4>
              <p className="text-xl font-semibold text-gray-900">
                ${data.indicators.sma200[data.indicators.sma200.length - 1].toFixed(2)}
              </p>
              <p className="text-xs text-gray-500">
                {latestPrice && latestPrice > data.indicators.sma200[data.indicators.sma200.length - 1] 
                  ? '価格は200日移動平均線を上回っています（強気）' 
                  : '価格は200日移動平均線を下回っています（弱気）'}
              </p>
            </div>
          )}
          
          {latestRSI !== null && (
            <div className="bg-gray-50 p-4 rounded-lg">
              <h4 className="text-sm font-medium text-gray-500 mb-1">RSI (14)</h4>
              <p className={`text-xl font-semibold ${
                latestRSI > 70 ? 'text-red-600' : latestRSI < 30 ? 'text-green-600' : 'text-gray-900'
              }`}>
                {latestRSI.toFixed(2)}
              </p>
              <p className="text-xs text-gray-500">
                {latestRSI > 70 ? '買われすぎ（売り圧力の可能性）' : 
                 latestRSI < 30 ? '売られすぎ（買い圧力の可能性）' : '中立的な範囲内'}
              </p>
            </div>
          )}
        </div>
      </div>
      
      {latestMACD && (
        <div className="mb-6">
          <h3 className="text-lg font-medium text-gray-900 mb-3">MACD</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-gray-50 p-4 rounded-lg">
              <h4 className="text-sm font-medium text-gray-500 mb-1">MACD ライン</h4>
              <p className="text-xl font-semibold text-gray-900">{latestMACD.line.toFixed(2)}</p>
            </div>
            <div className="bg-gray-50 p-4 rounded-lg">
              <h4 className="text-sm font-medium text-gray-500 mb-1">シグナルライン</h4>
              <p className="text-xl font-semibold text-gray-900">{latestMACD.signal.toFixed(2)}</p>
            </div>
            <div className="bg-gray-50 p-4 rounded-lg">
              <h4 className="text-sm font-medium text-gray-500 mb-1">ヒストグラム</h4>
              <p className={`text-xl font-semibold ${latestMACD.histogram >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                {latestMACD.histogram.toFixed(2)}
              </p>
              <p className="text-xs text-gray-500">
                {latestMACD.line > latestMACD.signal ? 'MACDはシグナルラインを上回っています（強気）' : 'MACDはシグナルラインを下回っています（弱気）'}
              </p>
            </div>
          </div>
        </div>
      )}
      
      <div>
        <h3 className="text-lg font-medium text-gray-900 mb-3">サポート/レジスタンスレベル</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <h4 className="text-sm font-medium text-gray-500 mb-2">サポートレベル</h4>
            {supportLevels.length > 0 ? (
              <ul className="space-y-1">
                {supportLevels.map((level, index) => (
                  <li key={index} className="text-gray-900">${level.toFixed(2)}</li>
                ))}
              </ul>
            ) : (
              <p className="text-gray-500">サポートレベルが見つかりませんでした</p>
            )}
          </div>
          <div>
            <h4 className="text-sm font-medium text-gray-500 mb-2">レジスタンスレベル</h4>
            {resistanceLevels.length > 0 ? (
              <ul className="space-y-1">
                {resistanceLevels.map((level, index) => (
                  <li key={index} className="text-gray-900">${level.toFixed(2)}</li>
                ))}
              </ul>
            ) : (
              <p className="text-gray-500">レジスタンスレベルが見つかりませんでした</p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default TechnicalAnalysis;
