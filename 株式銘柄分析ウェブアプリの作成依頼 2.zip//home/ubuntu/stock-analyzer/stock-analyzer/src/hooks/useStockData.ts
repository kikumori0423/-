import React from 'react';
import { useQuery } from '@tanstack/react-query';
import stockService from '../services/stockService';

// データ変換ユーティリティ関数
const transformChartData = (data) => {
  if (!data || !data.chart || !data.chart.result || data.chart.result.length === 0) {
    return null;
  }

  const result = data.chart.result[0];
  const timestamps = result.timestamp || [];
  const quotes = result.indicators.quote[0] || {};
  const adjclose = result.indicators.adjclose ? result.indicators.adjclose[0].adjclose : [];

  return {
    meta: result.meta,
    series: timestamps.map((timestamp, index) => ({
      date: new Date(timestamp * 1000).toISOString().split('T')[0],
      open: quotes.open ? quotes.open[index] : null,
      high: quotes.high ? quotes.high[index] : null,
      low: quotes.low ? quotes.low[index] : null,
      close: quotes.close ? quotes.close[index] : null,
      volume: quotes.volume ? quotes.volume[index] : null,
      adjClose: adjclose ? adjclose[index] : null
    }))
  };
};

const transformProfileData = (data) => {
  if (!data || !data.quoteSummary || !data.quoteSummary.result || data.quoteSummary.result.length === 0) {
    return null;
  }

  const profile = data.quoteSummary.result[0].summaryProfile;
  return {
    name: profile.longBusinessSummary ? profile.longBusinessSummary.split('.')[0] : '',
    description: profile.longBusinessSummary,
    sector: profile.sector,
    industry: profile.industry,
    employees: profile.fullTimeEmployees,
    website: profile.website,
    address: [profile.address1, profile.city, profile.zip, profile.country].filter(Boolean).join(', '),
    exchange: profile.industryDisp
  };
};

const transformInsightsData = (data) => {
  if (!data || !data.finance || !data.finance.result) {
    return null;
  }

  const insights = data.finance.result;
  return {
    technicalEvents: insights.instrumentInfo?.technicalEvents,
    keyTechnicals: insights.instrumentInfo?.keyTechnicals,
    valuation: insights.instrumentInfo?.valuation,
    recommendation: insights.recommendation,
    events: insights.events,
    reports: insights.reports,
    sigDevs: insights.sigDevs
  };
};

// カスタムフック: 株式データを取得
export const useStockData = (symbol) => {
  // 株価チャートデータを取得
  const chartQuery = useQuery({
    queryKey: ['stockChart', symbol],
    queryFn: () => stockService.getStockChart(symbol),
    enabled: !!symbol,
    staleTime: 5 * 60 * 1000 // 5分間キャッシュ
  });

  // 企業プロファイルデータを取得
  const profileQuery = useQuery({
    queryKey: ['stockProfile', symbol],
    queryFn: () => stockService.getStockProfile(symbol),
    enabled: !!symbol,
    staleTime: 60 * 60 * 1000 // 1時間キャッシュ
  });

  // 分析情報を取得
  const insightsQuery = useQuery({
    queryKey: ['stockInsights', symbol],
    queryFn: () => stockService.getStockInsights(symbol),
    enabled: !!symbol,
    staleTime: 30 * 60 * 1000 // 30分間キャッシュ
  });

  // 株主情報を取得
  const holdersQuery = useQuery({
    queryKey: ['stockHolders', symbol],
    queryFn: () => stockService.getStockHolders(symbol),
    enabled: !!symbol,
    staleTime: 24 * 60 * 60 * 1000 // 24時間キャッシュ
  });

  // 変換されたデータを返す
  return {
    chartData: {
      data: chartQuery.data ? transformChartData(chartQuery.data) : null,
      isLoading: chartQuery.isLoading,
      error: chartQuery.error
    },
    profileData: {
      data: profileQuery.data ? transformProfileData(profileQuery.data) : null,
      isLoading: profileQuery.isLoading,
      error: profileQuery.error
    },
    insightsData: {
      data: insightsQuery.data ? transformInsightsData(insightsQuery.data) : null,
      isLoading: insightsQuery.isLoading,
      error: insightsQuery.error
    },
    holdersData: {
      data: holdersQuery.data,
      isLoading: holdersQuery.isLoading,
      error: holdersQuery.error
    },
    isLoading: chartQuery.isLoading || profileQuery.isLoading || insightsQuery.isLoading || holdersQuery.isLoading,
    isError: chartQuery.isError || profileQuery.isError || insightsQuery.isError || holdersQuery.isError,
    error: chartQuery.error || profileQuery.error || insightsQuery.error || holdersQuery.error
  };
};

export default useStockData;
