#!/bin/bash

# 株式銘柄分析アプリケーション起動スクリプト

echo "株式銘柄分析ウェブアプリケーションを起動します..."

# バックエンドAPIサーバーの起動
echo "バックエンドAPIサーバーを起動しています..."
cd /home/ubuntu/stock-analyzer/stock-analyzer/src/services
python3 api.py &
API_PID=$!
echo "APIサーバーが起動しました (PID: $API_PID)"

# フロントエンドの起動
echo "フロントエンドアプリケーションを起動しています..."
cd /home/ubuntu/stock-analyzer/stock-analyzer
pnpm run dev &
FRONTEND_PID=$!
echo "フロントエンドが起動しました (PID: $FRONTEND_PID)"

echo "アプリケーションの起動が完了しました"
echo "ブラウザで http://localhost:5173 にアクセスしてください"
echo ""
echo "終了するには Ctrl+C を押してください"

# 終了時の処理
function cleanup {
  echo "アプリケーションを終了しています..."
  kill $API_PID
  kill $FRONTEND_PID
  echo "終了しました"
  exit 0
}

# シグナルハンドラの設定
trap cleanup SIGINT SIGTERM

# スクリプトを実行し続ける
wait
