import React from 'react';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, 
  ResponsiveContainer, PieChart, Pie, Cell
} from 'recharts';

interface FinancialChartProps {
  data: {
    barData?: Array<{
      name: string;
      value: number;
      color?: string;
    }>;
    pieData?: Array<{
      name: string;
      value: number;
      color?: string;
    }>;
    title: string;
    type: 'bar' | 'pie';
    yAxisLabel?: string;
    tooltipLabel?: string;
  };
  height?: number;
}

const FinancialChart: React.FC<FinancialChartProps> = ({ 
  data, 
  height = 300
}) => {
  const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884D8', '#82CA9D'];

  if (!data) {
    return (
      <div className="bg-white p-4 rounded-lg shadow-sm">
        <p className="text-gray-500">チャートデータが見つかりませんでした。</p>
      </div>
    );
  }

  // 金額フォーマットを調整
  const formatValue = (value) => {
    if (value >= 1000000000) {
      return `${(value / 1000000000).toFixed(1)}B`;
    } else if (value >= 1000000) {
      return `${(value / 1000000).toFixed(1)}M`;
    } else if (value >= 1000) {
      return `${(value / 1000).toFixed(1)}K`;
    }
    return value.toFixed(2);
  };

  return (
    <div className="bg-white p-4 rounded-lg shadow-sm">
      <h4 className="text-sm font-medium text-gray-700 mb-3">{data.title}</h4>
      
      {data.type === 'bar' && data.barData && (
        <ResponsiveContainer width="100%" height={height}>
          <BarChart
            data={data.barData}
            margin={{
              top: 5,
              right: 30,
              left: 20,
              bottom: 5,
            }}
          >
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="name" />
            <YAxis tickFormatter={formatValue} label={{ value: data.yAxisLabel, angle: -90, position: 'insideLeft' }} />
            <Tooltip 
              formatter={(value) => [formatValue(value), data.tooltipLabel || '値']}
            />
            <Legend />
            <Bar dataKey="value" name={data.tooltipLabel || '値'}>
              {data.barData.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={entry.color || COLORS[index % COLORS.length]} />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      )}
      
      {data.type === 'pie' && data.pieData && (
        <ResponsiveContainer width="100%" height={height}>
          <PieChart>
            <Pie
              data={data.pieData}
              cx="50%"
              cy="50%"
              labelLine={true}
              label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
              outerRadius={80}
              fill="#8884d8"
              dataKey="value"
            >
              {data.pieData.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={entry.color || COLORS[index % COLORS.length]} />
              ))}
            </Pie>
            <Tooltip formatter={(value) => [formatValue(value), '値']} />
            <Legend />
          </PieChart>
        </ResponsiveContainer>
      )}
    </div>
  );
};

export default FinancialChart;
