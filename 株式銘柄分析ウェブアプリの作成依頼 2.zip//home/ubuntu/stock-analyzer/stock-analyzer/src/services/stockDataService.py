import sys
sys.path.append('/opt/.manus/.sandbox-runtime')
from data_api import ApiClient

class StockDataService:
    def __init__(self):
        self.client = ApiClient()
    
    def get_stock_chart(self, symbol, region="US", interval="1mo", range="1y"):
        """
        株価チャートデータを取得する
        """
        try:
            return self.client.call_api('YahooFinance/get_stock_chart', query={
                'symbol': symbol,
                'region': region,
                'interval': interval,
                'range': range,
                'includeAdjustedClose': True
            })
        except Exception as e:
            print(f"Error fetching stock chart: {e}")
            return None
    
    def get_stock_profile(self, symbol, region="US"):
        """
        企業プロファイル情報を取得する
        """
        try:
            return self.client.call_api('YahooFinance/get_stock_profile', query={
                'symbol': symbol,
                'region': region
            })
        except Exception as e:
            print(f"Error fetching stock profile: {e}")
            return None
    
    def get_stock_insights(self, symbol):
        """
        株式の分析情報を取得する
        """
        try:
            return self.client.call_api('YahooFinance/get_stock_insights', query={
                'symbol': symbol
            })
        except Exception as e:
            print(f"Error fetching stock insights: {e}")
            return None
    
    def get_stock_holders(self, symbol, region="US"):
        """
        株主情報を取得する
        """
        try:
            return self.client.call_api('YahooFinance/get_stock_holders', query={
                'symbol': symbol,
                'region': region
            })
        except Exception as e:
            print(f"Error fetching stock holders: {e}")
            return None
    
    def get_stock_sec_filing(self, symbol, region="US"):
        """
        SEC提出書類情報を取得する
        """
        try:
            return self.client.call_api('YahooFinance/get_stock_sec_filing', query={
                'symbol': symbol,
                'region': region
            })
        except Exception as e:
            print(f"Error fetching SEC filings: {e}")
            return None
    
    def get_analyst_opinions(self, symbol, region="US"):
        """
        アナリストの意見を取得する
        """
        try:
            return self.client.call_api('YahooFinance/get_stock_what_analyst_are_saying', query={
                'symbol': symbol,
                'region': region
            })
        except Exception as e:
            print(f"Error fetching analyst opinions: {e}")
            return None

# 使用例
if __name__ == "__main__":
    service = StockDataService()
    
    # テスト用にApple株のデータを取得
    symbol = "AAPL"
    
    # チャートデータ取得
    chart_data = service.get_stock_chart(symbol)
    if chart_data:
        print(f"Successfully fetched chart data for {symbol}")
    
    # プロファイル情報取得
    profile_data = service.get_stock_profile(symbol)
    if profile_data:
        print(f"Successfully fetched profile data for {symbol}")
    
    # 分析情報取得
    insights_data = service.get_stock_insights(symbol)
    if insights_data:
        print(f"Successfully fetched insights data for {symbol}")
