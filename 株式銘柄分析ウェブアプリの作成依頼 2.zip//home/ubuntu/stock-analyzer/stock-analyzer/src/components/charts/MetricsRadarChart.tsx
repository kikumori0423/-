import React from 'react';
import { 
  RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, 
  Radar, ResponsiveContainer, Tooltip, Legend
} from 'recharts';

interface MetricsRadarChartProps {
  data: Array<{
    subject: string;
    value: number;
    fullMark: number;
  }>;
  title?: string;
  height?: number;
  loading?: boolean;
}

const MetricsRadarChart: React.FC<MetricsRadarChartProps> = ({
  data,
  title = '指標レーダーチャート',
  height = 300,
  loading = false
}) => {
  if (loading) {
    return (
      <div className="bg-white p-4 rounded-lg shadow-sm">
        <h4 className="text-sm font-medium text-gray-700 mb-3">{title}</h4>
        <div className="animate-pulse">
          <div className="h-60 bg-gray-200 rounded w-full"></div>
        </div>
      </div>
    );
  }

  if (!data || data.length === 0) {
    return (
      <div className="bg-white p-4 rounded-lg shadow-sm">
        <h4 className="text-sm font-medium text-gray-700 mb-3">{title}</h4>
        <p className="text-gray-500">データがありません</p>
      </div>
    );
  }

  return (
    <div className="bg-white p-4 rounded-lg shadow-sm">
      <h4 className="text-sm font-medium text-gray-700 mb-3">{title}</h4>
      <ResponsiveContainer width="100%" height={height}>
        <RadarChart cx="50%" cy="50%" outerRadius="80%" data={data}>
          <PolarGrid />
          <PolarAngleAxis dataKey="subject" />
          <PolarRadiusAxis angle={30} domain={[0, 100]} />
          <Radar
            name="指標値"
            dataKey="value"
            stroke="#8884d8"
            fill="#8884d8"
            fillOpacity={0.6}
          />
          <Tooltip formatter={(value) => [`${value}`, '値']} />
          <Legend />
        </RadarChart>
      </ResponsiveContainer>
    </div>
  );
};

export default MetricsRadarChart;
