import React from 'react';

interface InvestmentThesisProps {
  symbol: string;
  data: {
    swot?: {
      strengths: string[];
      weaknesses: string[];
      opportunities: string[];
      threats: string[];
    };
    recommendations?: {
      valueInvestor?: string;
      growthInvestor?: string;
      incomeInvestor?: string;
      momentumTrader?: string;
      shortTermTrader?: string;
    };
    summary?: string;
  } | null;
  loading: boolean;
}

const InvestmentThesis: React.FC<InvestmentThesisProps> = ({ symbol, data, loading }) => {
  if (loading) {
    return (
      <div className="bg-white p-6 rounded-lg shadow-md mb-6">
        <h2 className="text-xl font-semibold mb-4">投資論</h2>
        <div className="animate-pulse">
          <div className="h-4 bg-gray-200 rounded w-3/4 mb-4"></div>
          <div className="grid grid-cols-2 gap-4 mb-4">
            <div className="h-40 bg-gray-200 rounded"></div>
            <div className="h-40 bg-gray-200 rounded"></div>
            <div className="h-40 bg-gray-200 rounded"></div>
            <div className="h-40 bg-gray-200 rounded"></div>
          </div>
          <div className="h-4 bg-gray-200 rounded w-1/2 mb-2"></div>
          <div className="h-4 bg-gray-200 rounded w-full mb-2"></div>
        </div>
      </div>
    );
  }

  if (!data) {
    return (
      <div className="bg-white p-6 rounded-lg shadow-md mb-6">
        <h2 className="text-xl font-semibold mb-4">投資論</h2>
        <p className="text-gray-500">投資論データが見つかりませんでした。</p>
      </div>
    );
  }

  return (
    <div className="bg-white p-6 rounded-lg shadow-md mb-6">
      <h2 className="text-xl font-semibold mb-4">投資論</h2>
      
      {data.swot && (
        <div className="mb-6">
          <h3 className="text-lg font-medium text-gray-900 mb-3">SWOT分析</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="bg-green-50 p-4 rounded-lg">
              <h4 className="text-sm font-medium text-green-700 mb-2">強み (Strengths)</h4>
              <ul className="list-disc pl-5 space-y-1 text-gray-700">
                {data.swot.strengths.map((strength, index) => (
                  <li key={index}>{strength}</li>
                ))}
              </ul>
            </div>
            
            <div className="bg-red-50 p-4 rounded-lg">
              <h4 className="text-sm font-medium text-red-700 mb-2">弱み (Weaknesses)</h4>
              <ul className="list-disc pl-5 space-y-1 text-gray-700">
                {data.swot.weaknesses.map((weakness, index) => (
                  <li key={index}>{weakness}</li>
                ))}
              </ul>
            </div>
            
            <div className="bg-blue-50 p-4 rounded-lg">
              <h4 className="text-sm font-medium text-blue-700 mb-2">機会 (Opportunities)</h4>
              <ul className="list-disc pl-5 space-y-1 text-gray-700">
                {data.swot.opportunities.map((opportunity, index) => (
                  <li key={index}>{opportunity}</li>
                ))}
              </ul>
            </div>
            
            <div className="bg-yellow-50 p-4 rounded-lg">
              <h4 className="text-sm font-medium text-yellow-700 mb-2">脅威 (Threats)</h4>
              <ul className="list-disc pl-5 space-y-1 text-gray-700">
                {data.swot.threats.map((threat, index) => (
                  <li key={index}>{threat}</li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      )}
      
      {data.recommendations && (
        <div className="mb-6">
          <h3 className="text-lg font-medium text-gray-900 mb-3">投資家タイプ別推奨</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {data.recommendations.valueInvestor && (
              <div className="bg-gray-50 p-4 rounded-lg">
                <h4 className="text-sm font-medium text-gray-700 mb-2">バリュー投資家</h4>
                <p className="text-gray-700">{data.recommendations.valueInvestor}</p>
              </div>
            )}
            
            {data.recommendations.growthInvestor && (
              <div className="bg-gray-50 p-4 rounded-lg">
                <h4 className="text-sm font-medium text-gray-700 mb-2">成長株投資家</h4>
                <p className="text-gray-700">{data.recommendations.growthInvestor}</p>
              </div>
            )}
            
            {data.recommendations.incomeInvestor && (
              <div className="bg-gray-50 p-4 rounded-lg">
                <h4 className="text-sm font-medium text-gray-700 mb-2">インカム投資家</h4>
                <p className="text-gray-700">{data.recommendations.incomeInvestor}</p>
              </div>
            )}
            
            {data.recommendations.momentumTrader && (
              <div className="bg-gray-50 p-4 rounded-lg">
                <h4 className="text-sm font-medium text-gray-700 mb-2">モメンタム投資家</h4>
                <p className="text-gray-700">{data.recommendations.momentumTrader}</p>
              </div>
            )}
            
            {data.recommendations.shortTermTrader && (
              <div className="bg-gray-50 p-4 rounded-lg">
                <h4 className="text-sm font-medium text-gray-700 mb-2">短期トレーダー</h4>
                <p className="text-gray-700">{data.recommendations.shortTermTrader}</p>
              </div>
            )}
          </div>
        </div>
      )}
      
      {data.summary && (
        <div>
          <h3 className="text-lg font-medium text-gray-900 mb-3">総合評価</h3>
          <div className="bg-gray-50 p-4 rounded-lg">
            <p className="text-gray-700">{data.summary}</p>
          </div>
        </div>
      )}
    </div>
  );
};

export default InvestmentThesis;
