import React from 'react';

interface FinancialDataProps {
  symbol: string;
  data: {
    revenue?: number[];
    revenueGrowth?: number[];
    netIncome?: number[];
    profitMargin?: number[];
    operatingMargin?: number[];
    totalAssets?: number;
    totalLiabilities?: number;
    totalEquity?: number;
    cashFlow?: {
      operating?: number;
      investing?: number;
      financing?: number;
    };
    periods?: string[];
  } | null;
  loading: boolean;
}

const FinancialData: React.FC<FinancialDataProps> = ({ symbol, data, loading }) => {
  if (loading) {
    return (
      <div className="bg-white p-6 rounded-lg shadow-md mb-6">
        <h2 className="text-xl font-semibold mb-4">財務データ</h2>
        <div className="animate-pulse">
          <div className="h-4 bg-gray-200 rounded w-3/4 mb-4"></div>
          <div className="h-40 bg-gray-200 rounded w-full mb-4"></div>
          <div className="grid grid-cols-2 gap-4">
            <div className="h-4 bg-gray-200 rounded"></div>
            <div className="h-4 bg-gray-200 rounded"></div>
            <div className="h-4 bg-gray-200 rounded"></div>
            <div className="h-4 bg-gray-200 rounded"></div>
          </div>
        </div>
      </div>
    );
  }

  if (!data) {
    return (
      <div className="bg-white p-6 rounded-lg shadow-md mb-6">
        <h2 className="text-xl font-semibold mb-4">財務データ</h2>
        <p className="text-gray-500">財務データが見つかりませんでした。</p>
      </div>
    );
  }

  return (
    <div className="bg-white p-6 rounded-lg shadow-md mb-6">
      <h2 className="text-xl font-semibold mb-4">財務データ</h2>
      
      <div className="mb-6">
        <h3 className="text-lg font-medium text-gray-900 mb-3">収益動向</h3>
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">期間</th>
                {data.periods?.map((period, index) => (
                  <th key={index} scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    {period}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              <tr>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">収益 (百万円)</td>
                {data.revenue?.map((value, index) => (
                  <td key={index} className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {(value / 1000000).toFixed(2)}
                  </td>
                ))}
              </tr>
              <tr>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">収益成長率 (%)</td>
                {data.revenueGrowth?.map((value, index) => (
                  <td key={index} className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {(value * 100).toFixed(2)}%
                  </td>
                ))}
              </tr>
              <tr>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">純利益 (百万円)</td>
                {data.netIncome?.map((value, index) => (
                  <td key={index} className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {(value / 1000000).toFixed(2)}
                  </td>
                ))}
              </tr>
              <tr>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">利益率 (%)</td>
                {data.profitMargin?.map((value, index) => (
                  <td key={index} className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {(value * 100).toFixed(2)}%
                  </td>
                ))}
              </tr>
              <tr>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">営業利益率 (%)</td>
                {data.operatingMargin?.map((value, index) => (
                  <td key={index} className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {(value * 100).toFixed(2)}%
                  </td>
                ))}
              </tr>
            </tbody>
          </table>
        </div>
      </div>
      
      <div className="mb-6">
        <h3 className="text-lg font-medium text-gray-900 mb-3">貸借対照表</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-gray-50 p-4 rounded-lg">
            <h4 className="text-sm font-medium text-gray-500 mb-1">総資産</h4>
            <p className="text-xl font-semibold text-gray-900">
              {data.totalAssets ? (data.totalAssets / 1000000).toFixed(2) + 'M' : 'N/A'}
            </p>
          </div>
          <div className="bg-gray-50 p-4 rounded-lg">
            <h4 className="text-sm font-medium text-gray-500 mb-1">総負債</h4>
            <p className="text-xl font-semibold text-gray-900">
              {data.totalLiabilities ? (data.totalLiabilities / 1000000).toFixed(2) + 'M' : 'N/A'}
            </p>
          </div>
          <div className="bg-gray-50 p-4 rounded-lg">
            <h4 className="text-sm font-medium text-gray-500 mb-1">株主資本</h4>
            <p className="text-xl font-semibold text-gray-900">
              {data.totalEquity ? (data.totalEquity / 1000000).toFixed(2) + 'M' : 'N/A'}
            </p>
          </div>
        </div>
      </div>
      
      <div>
        <h3 className="text-lg font-medium text-gray-900 mb-3">キャッシュフロー分析</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-gray-50 p-4 rounded-lg">
            <h4 className="text-sm font-medium text-gray-500 mb-1">営業キャッシュフロー</h4>
            <p className={`text-xl font-semibold ${data.cashFlow?.operating && data.cashFlow.operating > 0 ? 'text-green-600' : 'text-red-600'}`}>
              {data.cashFlow?.operating ? (data.cashFlow.operating / 1000000).toFixed(2) + 'M' : 'N/A'}
            </p>
          </div>
          <div className="bg-gray-50 p-4 rounded-lg">
            <h4 className="text-sm font-medium text-gray-500 mb-1">投資キャッシュフロー</h4>
            <p className={`text-xl font-semibold ${data.cashFlow?.investing && data.cashFlow.investing > 0 ? 'text-green-600' : 'text-red-600'}`}>
              {data.cashFlow?.investing ? (data.cashFlow.investing / 1000000).toFixed(2) + 'M' : 'N/A'}
            </p>
          </div>
          <div className="bg-gray-50 p-4 rounded-lg">
            <h4 className="text-sm font-medium text-gray-500 mb-1">財務キャッシュフロー</h4>
            <p className={`text-xl font-semibold ${data.cashFlow?.financing && data.cashFlow.financing > 0 ? 'text-green-600' : 'text-red-600'}`}>
              {data.cashFlow?.financing ? (data.cashFlow.financing / 1000000).toFixed(2) + 'M' : 'N/A'}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FinancialData;
